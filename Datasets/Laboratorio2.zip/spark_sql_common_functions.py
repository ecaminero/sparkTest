
# coding: utf-8

# # Parte II: Uso de funciones de SparkSQL

# Crearemos tablas de SparkSQL a partir de los datos. Use los siguientes comandos para crear los Dataframes M y R:

# In[ ]:


from pyspark.sql import SQLContext, Row
from pyspark.sql.functions import asc, desc
sqlContext = SQLContext(sc)


# In[ ]:


movieText = sc.textFile('/user/cloudera/movies.dat')
ratingText = sc.textFile('/user/cloudera/ratings.dat')


# In[ ]:


ratingsData = ratingText.map(lambda line: line.split(';'))
movieData = movieText.map(lambda line: line.split(';'))


# In[ ]:


movies = movieData.map(lambda m: Row(movie_id=int(m[0]), title=m[1], genres=m[2]))
M = sqlContext.createDataFrame(movies)


# In[ ]:


ratings = ratingsData.map(lambda r: Row(user_id=int(r[0]), movie_id=int(r[1]), rating=int(r[2]), timestamp=r[3]))
R = sqlContext.createDataFrame(ratings)

